/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mobil;

import java.sql.SQLException;
import controler.c_login ;
import view.login;
import model.m_login;
import controler.c_datamobil;
import view.datamobil;
import model.m_datamobil;
import controler.c_datashowroom;
import view.datashowroom;
import model.m_datashowroom;

public class Mobil {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
//        new c_datamobil();
//          new c_datashowroom();
        controler.c_login log = new controler.c_login(new view.login(), new model.m_login());
        // TODO code application logic here
    }
    
}
