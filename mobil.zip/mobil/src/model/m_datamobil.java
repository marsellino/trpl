
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractListModel;
import javax.swing.DefaultListModel;
import javax.swing.table.DefaultTableModel;
import model.koneksi;

public class m_datamobil extends model {
    koneksi kon;
    private String idmobil = null;
    private String tanggalmasuk;
    private String jenistipe;
    private String warna;
    private String tahunproduksi;
    private String harga;
    private String jumlah;
    
    private DefaultTableModel tableModel;
    private DefaultListModel listModel;
    
    public m_datamobil() throws SQLException {
        kon = new koneksi();

        String header[] = {"NO","id mobil", "tanggal masuk", "jenis tipe", "warna","tahunproduksi","harga","jumlah"};
        tableModel = new DefaultTableModel(null, header);
        listModel = new DefaultListModel();
        ambilData();

    }
    public DefaultTableModel getTableModel() throws SQLException {
        for (int i = tableModel.getRowCount() - 1; i >= 0; i--) {
            tableModel.removeRow(i);
        }
        String sql = "select * from datamobil";

        ResultSet rs = kon.getResult(sql);
        int n = 1;
        while (rs.next()) {
            String kolom[] = new String[8];
            for (int i = 1; i < kolom.length; i++) {
                kolom[i] = rs.getString(i);

            }
            kolom[0] = Integer.toString(n);
            tableModel.addRow(kolom);

            n++;
        }
        return tableModel;
    }

    public void ambilData() throws SQLException {
        listModel.clear();
        String sql = "SELECT `jenistipe`  FROM `datamobil`";
        ResultSet rs = kon.getResult(sql);

        try {
            while (rs.next()) {
                //lakukan penelusuran baris
                String op = rs.getString(1);
                System.out.println(op);
                listModel.addElement(op);
            }

        } catch (Exception e) {
//            System.out.println("ERROR");
            System.err.println(e);
        }
    }
    public DefaultListModel getListModel() throws SQLException {

        return listModel;
    }

    public void setIdMobil(String IdMobil) {
        this.idmobil = IdMobil;
    }

    public void settanggalMasuk(String tanggalMasuk) {
        this.tanggalmasuk = tanggalMasuk;
    }

    public void setjenistipe(String jenistipe) {
        this.jenistipe = jenistipe;
    }

    public void setwarna(String warna) {
        this.warna = warna;
    }

    public void settahunproduksi(String tahunproduksi) {
        this.tahunproduksi = tahunproduksi;
    }
    public void setharga(String harga) {
        this.harga = harga;
    }
    public void setjumlah(String jumlah) {
        this.jumlah = jumlah;
    }
    
    public void setSelectedRow(int baris) {
        this.idmobil = tableModel.getValueAt(baris, 1).toString();
        this.tanggalmasuk = tableModel.getValueAt(baris, 2).toString();
        this.jenistipe = tableModel.getValueAt(baris, 3).toString();
        this.warna = tableModel.getValueAt(baris, 4).toString();
        this.tahunproduksi = tableModel.getValueAt(baris, 5).toString();
        this.harga = tableModel.getValueAt(baris, 6).toString();
        this.jumlah = tableModel.getValueAt(baris, 7).toString();
        
    }
    public String getidmobil() {
        return idmobil;
    }

    public String gettanggalmasuk() {
        return tanggalmasuk;
    }

    public String getjenistipe() {
        return jenistipe;
    }

    public String getwarna() {
        return warna;
    }

    public String gettahunproduksi() {
        return tahunproduksi;
    }
     public String getharga() {
        return harga;
    }
      public String getjumlah() {
        return jumlah;
    }
    

    @Override
    public void simpan() {
    try {
            String query = "INSERT INTO `mobil`.`datamobil` (`idmobil` ,`tanggalmasuk`, `jenistipe`, `warna`, `tahunproduksi`, `harga`, `jumlah` ) "
                    + "VALUES (NULL ,'" + tanggalmasuk + "', '" + jenistipe + "', '" + warna + "','" + tahunproduksi + "','" + harga + "','" + jumlah + "');";
            kon.execute(query);
        } catch (SQLException e) {

            System.out.println(e);
        }
    }

    @Override
    public void ubah() {
     try {
            String query = "update `datamobil` set `tanggalmasuk`= '" + tanggalmasuk + "',`jenistipe`= '" + jenistipe + "', `warna` = '" + warna + "', `tahunproduksi` = '" + tahunproduksi + "', `harga` = '" + harga + "', `jumlah` = '" + jumlah + "' where `idmobil` = '" + idmobil + "'";
            System.out.println(query);
            kon.execute(query);
        } catch (Exception e) {
            System.out.println(e);

        }}

    @Override
    public void hapus() {
    String query = "DELETE FROM `datamobil` WHERE idmobil = '" + idmobil + "';";
        System.out.println(query);
        try {
            kon.execute(query);
        } catch (Exception e) {
            System.out.println(e);

        }
    }
     public String[] getMobil() throws SQLException {
        String query = "select distinct (jenistipe) from datamobil";
        String list[];
        ResultSet hasil = kon.getResult(query);
        int count = 0;
        while (hasil.next()) {
            count++;
        }
        hasil.beforeFirst();
        list = new String[count];
        int i = 0;
        while (hasil.next()) {
            list[i] = hasil.getString(1);
            i++;
        }
        return list;
    }
      public int[] getPermintaanBulanan(String jenistipe) throws SQLException {
        String query = "SELECT sum(`idpemesanan`) AS total FROM `pemesanan` WHERE TIMESTAMPDIFF(month, `tglpemesanan`, now()) <= 3 and `jenistipe` = '" + jenistipe + "' group by `jenistipe`, month(`tglpemesanan`), year(`tglpemesanan`) order BY TIMESTAMPDIFF(month, `tglpemesanan`, now())";
        int list[];
        ResultSet hasil = kon.getResult(query);
        int count = 0;
        while (hasil.next()) {
            count++;
        }
        hasil.beforeFirst();
        list = new int[count];
        int i = 0;
        while (hasil.next()) {
            list[i] = -hasil.getInt(4);
            i++;
        }
        return list;
    }
}
