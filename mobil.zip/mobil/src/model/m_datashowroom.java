
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractListModel;
import javax.swing.DefaultListModel;
import javax.swing.table.DefaultTableModel;
import model.koneksi;

public class m_datashowroom extends model {
    koneksi kon;
    private String idshowroom = null;
    private String namashowroom;
    private String alamat;
    private String nohp;
    private DefaultTableModel tableModel;
    private DefaultListModel listModel;

    public m_datashowroom () throws SQLException {
        kon = new koneksi();

        String header[] = {"NO", "id showroom", "nama showroom", "alamat showroom","no HP",};
        tableModel = new DefaultTableModel(null, header);
        listModel = new DefaultListModel();
        ambilData();
    }
    
    public DefaultTableModel getTableModel() throws SQLException {
        for (int i = tableModel.getRowCount() - 1; i >= 0; i--) {
            tableModel.removeRow(i);
        }
        String sql = "select * from datashowroom";

        ResultSet rs = kon.getResult(sql);
        int n = 1;
        while (rs.next()) {
            String kolom[] = new String[5];
            for (int i = 1; i < kolom.length; i++) {
                kolom[i] = rs.getString(i);

            }
            kolom[0] = Integer.toString(n);
            tableModel.addRow(kolom);

            n++;
        }
        return tableModel;
    }

    public void ambilData() throws SQLException {
        listModel.clear();
        String sql = "SELECT `namashowroom`  FROM `datashowroom`";
        ResultSet rs = kon.getResult(sql);

        try {
            while (rs.next()) {
                //lakukan penelusuran baris
                String op = rs.getString(1);
                System.out.println(op);
                listModel.addElement(op);
            }

        } catch (Exception e) {
//            System.out.println("ERROR");
            System.err.println(e);
        }
    }
    public DefaultListModel getListModel() throws SQLException {

        return listModel;
    }

    public void setidShowroom(String idShowroom) {
        this.idshowroom = idShowroom;
    }

    public void setnamaShowroom(String namaShowroom) {
        this.namashowroom = namaShowroom;
    }

    public void setalamatShowroom(String alamatShowroom) {
        this.alamat = alamatShowroom;
    }

    public void setnoHp(String noHp) {
        this.nohp = noHp;
    }

    public void setSelectedRow(int baris) {
        this.idshowroom = tableModel.getValueAt(baris, 1).toString();
        this.namashowroom = tableModel.getValueAt(baris, 2).toString();
        this.alamat = tableModel.getValueAt(baris, 3).toString();
        this.nohp = tableModel.getValueAt(baris, 4).toString();
    }
    public String getidShowroom() {
        return idshowroom;
    }

    public String getnamaShowroom() {
        return namashowroom;
    }

    public String getalamatShowroom() {
        return alamat;
    }

    public String getnoHp() {
        return nohp;
    }
    
    @Override
    public void simpan() {
        try {
            String query = "INSERT INTO `mobil`.`datashowroom` (`idshowroom` ,`namashowroom`, `alamat`, `nohp` ) "
                    + "VALUES (NULL ,'" + namashowroom + "', '" + alamat + "', '" + nohp + "');";
            kon.execute(query);
        } catch (SQLException e) {

            System.out.println(e);
        }
    }

    @Override
    public void ubah() {
     try {
            String query = "update `datashowroom` set `namashowroom`= '" + namashowroom + "',`alamat`= '" + alamat + "', `nohp` = '" + nohp + "' where `idshowroom` = '" + idshowroom + "'";
            System.out.println(query);
            kon.execute(query);
        } catch (Exception e) {
            System.out.println(e);

        }}

    @Override
    public void hapus() {
     String query = "DELETE FROM `showroom` WHERE idshowroom = '" + idshowroom + "';";
        System.out.println(query);
        try {
            kon.execute(query);
        } catch (Exception e) {
            System.out.println(e);

        }
    }
}
