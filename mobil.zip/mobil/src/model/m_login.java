/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.koneksi;

public class m_login extends koneksi {

    

    public int cekLevel(String Username, String Password) throws SQLException {
        String query = "SELECT * FROM user WHERE username='"
                + Username + "' AND password='" + Password + "'";
        ResultSet rs = getResult(query);
        rs.last();
        if (rs.getRow() == 1) {
            String query2 = "SELECT * FROM user WHERE idlevel="
                    + rs.getString("idlevel");
            ResultSet rs2 = getResult(query2);
            rs2.next();
            String title = rs2.getString("idlevel");

            if (title.equals("1")) {
                return 1;
            } else if (title.equals("2")) {
                return 2;
            } else {
                return 3;
            }
        } else {
            return 0;
        }
    }
}
