
package model;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class koneksi {
    Connection kon;
    Statement stm;

    public koneksi() {
        try {
            String username = "root";
            String password = "";
            String database = "mobil";
            String url = "jdbc:mysql://localhost:3306/" + database;
            Class.forName("com.mysql.jdbc.Driver");
            kon = DriverManager.getConnection(url, username, password);
            stm = kon.createStatement();
            System.out.println("Koneksi Berhasil");

        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Koneksi gagal. Kesalahan : " + e);
        }

    }


    public ResultSet getResult(String sql) throws SQLException {
        ResultSet rs = stm.executeQuery(sql);
        return rs;
    }

    public void execute(String sql) throws SQLException {
        this.stm.executeUpdate(sql);
    }
}


