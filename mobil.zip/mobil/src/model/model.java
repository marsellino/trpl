
package model;

import javax.swing.table.DefaultTableModel;

public abstract class model {
    protected abstract void simpan();

    protected abstract void ubah();

    protected abstract void hapus();
    
}
