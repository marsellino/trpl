package controler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.m_datamobil;
import view.datamobil;
import view.peramalan;

public class c_peramalan {

    peramalan views;
    m_datamobil models;

    public c_peramalan() throws SQLException {
        this.views = new peramalan();
        this.models = new m_datamobil();
        this.views.setVisible(true);
        this.views.setMobil(models.getMobil());
        this.views.klikcb(new tblcb());
        this. views.kliksikat(new tblsikat());
    }

    private class tblcb implements ActionListener {

        public tblcb() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                views.setData(models.getPermintaanBulanan(views.getjenistipe()));
            } catch (SQLException ex) {
                Logger.getLogger(c_peramalan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class tblsikat implements ActionListener {

        public tblsikat() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            views.setHasil(WMA(views.getData()));
        }

    }

    public int WMA(int bulan[]) { //weighted moving avarage
        int[] data = new int[3];
        int hasil = 0;
        data = bulan;
        for (int i = 0; i < data.length; i++) {
            hasil += data[i] * (i + 1);
        }
        hasil = (data[0] * 1 + data[1] * 2 + data[2] * 3) / 6;
        return hasil;
    }

}
