
package controler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.m_login;
import view.login;
import java.sql.SQLException;
import view.login;
import model.m_login;

public class c_login {
    protected login views;
    private m_login models;
    
    public c_login(login views, m_login models) throws SQLException {
        this.views = views;
        this.models = models;
        this.views.setVisible(true);
        this.views.klikLogin(new tbllogin());

    }

    private class tbllogin implements ActionListener {

        public tbllogin() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
         if (views.getUsername().equals("") || views.getPassword().equals("")) {
                views.optionPane("USERNAME DAN PASSWORD TIDAK BOLEH KOSONG");
            } else {
                try {
                    int level = models.cekLevel(views.getUsername(), views.getPassword());
                    System.out.println(level);
                    if (level == 1) {
                        views.setVisible(false);
                        controler.c_homeshowroom showroom = new controler.c_homeshowroom(new view.homeshowroom());
                    } else if (level == 2) {
                        views.setVisible(false);
                        controler.c_homesupplier supplier = new controler.c_homesupplier(new view.homesupplier());
                    } else if (level == 3) {
                        views.setVisible(false);

                    }

                } catch (SQLException ex) {
                    System.err.println(ex.getStackTrace());
                    System.out.println("errrroorrrr");
                    views.optionPane("USERNAME ATAU PASSWORD SALAH");
                }
            }
        }
    }
}
