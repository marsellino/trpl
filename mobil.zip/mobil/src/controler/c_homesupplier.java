/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import view.homesupplier;

public class c_homesupplier {
    private homesupplier views;


public c_homesupplier (homesupplier views) {
        this.views = views;
        this.views.setVisible(true);

        this.views.klikhomesupplier(new c_homesupplier.tblshome());
        this.views.klikdatamobil(new c_homesupplier.tblsdatamobil());
        this.views.klikdatashowroom(new c_homesupplier.tblsdatashowroom());
        this.views.kliklogout(new c_homesupplier.tblslogout());

}

    private class tblsdatashowroom implements ActionListener {

        public tblsdatashowroom() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
        views.setVisible(false);
            try {

                controler.c_datashowroom datashowroom = new controler.c_datashowroom();
            } catch (SQLException ex) {
                Logger.getLogger(c_homesupplier.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class tblsdatamobil implements ActionListener {

        public tblsdatamobil() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
        views.setVisible(false);
            try {

                controler.c_datamobil datamobil = new controler.c_datamobil();
            } catch (SQLException ex) {
                Logger.getLogger(c_homesupplier.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class tblshome implements ActionListener {

        public tblshome() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private class tblslogout implements ActionListener {

        public tblslogout() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
        views.setVisible(false);
            try {
                controler.c_login logout = new controler.c_login(new view.login(), new model.m_login());

            } catch (SQLException ex) {
                Logger.getLogger(c_datamobil.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }


    }
