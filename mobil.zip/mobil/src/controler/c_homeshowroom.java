/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import view.homeshowroom;

public class c_homeshowroom {
    private homeshowroom views;
    
    public c_homeshowroom (homeshowroom views) {
        this.views = views;
        this.views.setVisible(true);

        this.views.klikhomeshowroom(new c_homeshowroom.tblshome());
//        this.views.klikdatamobil(new c_homegudang.tblstokroti());
        this.views.kliklogout(new c_homeshowroom.tblslogout());

}

    private class tblshome implements ActionListener {

        public tblshome() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private class tblslogout implements ActionListener {

        public tblslogout() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

}
