/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.m_datashowroom;
import view.datashowroom;

public class c_datashowroom {
    datashowroom views;
    m_datashowroom models;
    
    public c_datashowroom() throws SQLException {
        this.views = new datashowroom();
        this.models = new m_datashowroom();
        System.out.println("berhasil masuk");
        this.views.setViewTabel(this.models.getTableModel());

        this.views.setVisible(true);
        this.views.kliksimpan(new tblsimpan());
        this.views.klikubah(new tblubah());
        this.views.klikhapus(new tblhapus());
        this.views.klikbatal(new tblbatal());
        this.views.klikHome(new tblhome());
        this.views.klikdatamobil(new tbldatamobil());
        this.views.kliklogout(new tbllogout());

    }

    private class tbldatamobil implements ActionListener {

        public tbldatamobil() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
        views.setVisible(false);
            try {
                controler.c_datamobil datamobil = new controler.c_datamobil();
            } catch (SQLException ex) {
                Logger.getLogger(c_datamobil.class.getName()).log(Level.SEVERE, null, ex);
            } 
        }
    }

    private class tblsimpan implements ActionListener {

        public tblsimpan() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
         models.setidShowroom(views.getIdShowroom());
            models.setnamaShowroom(views.getnamaShowroom());
            models.setalamatShowroom(views.getalamatshowroom());
            models.setnoHp(views.getnohp());
            try {
                if (views.getIdShowroom().equals("")) {
                    if (views.getnamaShowroom().equals("") || views.getalamatshowroom().equals("") || views.getnohp().equals("")) {

                        views.optionPane();
                    } else {
                        models.simpan();

                        models.getTableModel();

                    }
                } else if (!views.getIdShowroom().equals("")) {
                     if (views.getnamaShowroom().equals("") || views.getalamatshowroom().equals("") || views.getnohp().equals("")) {
                        views.optionPane();
                    } else {
                        models.ubah();
                        models.getTableModel();
                    }
                }
            } catch (SQLException ex) {
                Logger.getLogger(c_datashowroom.class.getName()).log(Level.SEVERE, null, ex);
            }
            views.getBatal();
        }
    }

    private class tblubah implements ActionListener {

        public tblubah() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
        models.setSelectedRow(views.getSelectedRow());
            views.setIdShowroom(models.getidShowroom());
            views.setnamaShowroom(models.getnamaShowroom());
            views.setalamatShowroom(models.getalamatShowroom());
            views.setnoHp(models.getnoHp());
        }
    }

    private class tblhapus implements ActionListener {

        public tblhapus() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
        models.setSelectedRow(views.getSelectedRow());
            if (views.optionPane("Apakah anda yakin ingin menghapus data tersebut?") == JOptionPane.YES_OPTION) {
                models.hapus();
                try {
                    views.setViewTabel(models.getTableModel());
                } catch (SQLException ex) {
                    Logger.getLogger(c_datashowroom.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                views.setVisible(true);
            }
        }
    }

    private class tblbatal implements ActionListener {

        public tblbatal() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
        views.getBatal();  
        }
    }

    private class tblhome implements ActionListener {

        public tblhome() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
        controler.c_homesupplier home = new controler.c_homesupplier(new view.homesupplier());
            views.setVisible(false); 
        }
    }

    private class tbllogout implements ActionListener {

        public tbllogout() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
        views.setVisible(false);
            try {
                controler.c_login logout = new controler.c_login(new view.login(), new model.m_login());

            } catch (SQLException ex) {
                Logger.getLogger(c_datashowroom.class.getName()).log(Level.SEVERE, null, ex);
            } 
        }
    }
}
